package com.example.hallbook;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HallbookApplicationTests {

	@Test
	void contextLoads() {
	}

}
