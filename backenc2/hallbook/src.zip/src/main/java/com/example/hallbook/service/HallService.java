
// File: service/HallService.java
package com.example.hallbook.service;

import com.example.hallbook.dto.request.HallRequest;
import com.example.hallbook.dto.response.HallImageResponse;
import com.example.hallbook.dto.response.HallResponse;
import com.example.hallbook.entity.*;
import com.example.hallbook.exception.ResourceNotFoundException;
import com.example.hallbook.exception.UnauthorizedException;
import com.example.hallbook.repository.HallImageRepository;
import com.example.hallbook.repository.HallRepository;
import com.example.hallbook.repository.UserRepository;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.math.BigDecimal;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class HallService {

    private final HallRepository hallRepository;
    private final UserRepository userRepository;
    private final HallImageRepository hallImageRepository;
    private final ObjectMapper objectMapper;

    @Transactional
    public HallResponse createHall(HallRequest request, Long ownerId) {
        User owner = userRepository.findById(ownerId)
                .orElseThrow(() -> new ResourceNotFoundException("Owner not found"));

        if (owner.getRole() != Role.OWNER && owner.getRole() != Role.ADMIN) {
            throw new UnauthorizedException("Only owners can create halls");
        }

        Hall hall = Hall.builder()
                .owner(owner)
                .name(request.getName())
                .description(request.getDescription())
                .address(request.getAddress())
                .city(request.getCity())
                .state(request.getState())
                .pincode(request.getPincode())
                .latitude(request.getLatitude())
                .longitude(request.getLongitude())
                .capacity(request.getCapacity())
                .pricePerHour(request.getPricePerHour())
                .hallType(request.getHallType())
                .facilities(convertListToJson(request.getFacilities()))
                .status(HallStatus.PENDING)
                .isActive(true)
                .rating(BigDecimal.ZERO)
                .totalBookings(0)
                .build();

        Hall savedHall = hallRepository.save(hall);
        return mapToHallResponse(savedHall);
    }

    public List<HallResponse> searchHalls(String city, BigDecimal minPrice, BigDecimal maxPrice,
                                         Integer capacity, HallType hallType, String sortBy) {
        List<Hall> halls = hallRepository.searchHalls(city, minPrice, maxPrice, capacity, hallType);

        return halls.stream()
                .sorted(getComparator(sortBy))
                .map(this::mapToHallResponse)
                .collect(Collectors.toList());
    }

    public HallResponse getHallById(Long id) {
        Hall hall = hallRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Hall not found"));
        return mapToHallResponse(hall);
    }

    @Transactional
    public HallResponse updateHall(Long id, HallRequest request, Long userId) {
        Hall hall = hallRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Hall not found"));

        User user = userRepository.findById(userId)
                .orElseThrow(() -> new ResourceNotFoundException("User not found"));

        if (!hall.getOwner().getId().equals(userId) && user.getRole() != Role.ADMIN) {
            throw new UnauthorizedException("You don't have permission to update this hall");
        }

        hall.setName(request.getName());
        hall.setDescription(request.getDescription());
        hall.setAddress(request.getAddress());
        hall.setCity(request.getCity());
        hall.setState(request.getState());
        hall.setPincode(request.getPincode());
        hall.setLatitude(request.getLatitude());
        hall.setLongitude(request.getLongitude());
        hall.setCapacity(request.getCapacity());
        hall.setPricePerHour(request.getPricePerHour());
        hall.setHallType(request.getHallType());
        hall.setFacilities(convertListToJson(request.getFacilities()));

        Hall updatedHall = hallRepository.save(hall);
        return mapToHallResponse(updatedHall);
    }

    @Transactional
    public void deleteHall(Long id, Long userId) {
        Hall hall = hallRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Hall not found"));

        User user = userRepository.findById(userId)
                .orElseThrow(() -> new ResourceNotFoundException("User not found"));

        if (!hall.getOwner().getId().equals(userId) && user.getRole() != Role.ADMIN) {
            throw new UnauthorizedException("You don't have permission to delete this hall");
        }

        hall.setIsActive(false);
        hallRepository.save(hall);
    }

    public List<HallResponse> getOwnerHalls(Long ownerId) {
        return hallRepository.findByOwnerId(ownerId).stream()
                .map(this::mapToHallResponse)
                .collect(Collectors.toList());
    }

    public HallResponse mapToHallResponse(Hall hall) {
        List<HallImageResponse> images = hallImageRepository.findByHall(hall).stream()
                .map(img -> HallImageResponse.builder()
                        .id(img.getId())
                        .imageUrl(img.getImageUrl())
                        .isPrimary(img.getIsPrimary())
                        .aiTags(convertJsonToList(img.getAiTags()))
                        .build())
                .collect(Collectors.toList());

        String primaryImage = images.stream()
                .filter(HallImageResponse::getIsPrimary)
                .map(HallImageResponse::getImageUrl)
                .findFirst()
                .orElse(images.isEmpty() ? null : images.get(0).getImageUrl());

        return HallResponse.builder()
                .id(hall.getId())
                .ownerId(hall.getOwner().getId())
                .ownerName(hall.getOwner().getFullName())
                .name(hall.getName())
                .description(hall.getDescription())
                .address(hall.getAddress())
                .city(hall.getCity())
                .state(hall.getState())
                .pincode(hall.getPincode())
                .latitude(hall.getLatitude())
                .longitude(hall.getLongitude())
                .capacity(hall.getCapacity())
                .pricePerHour(hall.getPricePerHour())
                .hallType(hall.getHallType())
                .facilities(convertJsonToList(hall.getFacilities()))
                .status(hall.getStatus())
                .isActive(hall.getIsActive())
                .rating(hall.getRating())
                .totalBookings(hall.getTotalBookings())
                .images(images)
                .primaryImage(primaryImage)
                .build();
    }

    