package com.example.hallbook.dto.response;

import lombok.*;
import java.math.BigDecimal;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class AdminStatsResponse {
    private Long totalUsers;
    private Long totalHalls;
    private Long totalBookings;
    private BigDecimal totalRevenue;
}
