
// File: controller/AdminController.java
package com.example.hallbook.controller;

import com.example.hallbook.dto.response.AdminStatsResponse;
import com.example.hallbook.dto.response.ApiResponse;
import com.example.hallbook.dto.response.HallResponse;
import com.example.hallbook.service.AdminService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/api/admin")
@RequiredArgsConstructor
@PreAuthorize("hasRole('ADMIN')")
@CrossOrigin(origins = {"http://localhost:3000", "http://localhost:5173"}, allowCredentials = "true")
public class AdminController {

    private final AdminService adminService;

    @GetMapping("/stats")
    public ResponseEntity<AdminStatsResponse> getAdminStats() {
        AdminStatsResponse stats = adminService.getAdminStats();
        return ResponseEntity.ok(stats);
    }

    @GetMapping("/pending-approvals")
    public ResponseEntity<List<HallResponse>> getPendingApprovals() {
        List<HallResponse> halls = adminService.getPendingHallApprovals();
        return ResponseEntity.ok(halls);
    }

    @PutMapping("/halls/{hallId}/approve")
    public ResponseEntity<ApiResponse> approveHall(@PathVariable Long hallId) {
        adminService.approveHall(hallId);
        return ResponseEntity.ok(new ApiResponse(true, "Hall approved successfully"));
    }

    @PutMapping("/halls/{hallId}/reject")
    public ResponseEntity<ApiResponse> rejectHall(
            @PathVariable Long hallId,
            @RequestParam(required = false) String reason) {
        adminService.rejectHall(hallId, reason);
        return ResponseEntity.ok(new ApiResponse(true, "Hall rejected"));
    }

    @DeleteMapping("/users/{userId}")
    public ResponseEntity<ApiResponse> deactivateUser(@PathVariable Long userId) {
        adminService.deactivateUser(userId);
        return ResponseEntity.ok(new ApiResponse(true, "User deactivated"));
    }
}