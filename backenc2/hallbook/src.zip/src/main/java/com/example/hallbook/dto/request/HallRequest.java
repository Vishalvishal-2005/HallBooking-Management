package com.example.hallbook.dto.request;

import lombok.*;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalTime;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class HallRequest {
    private String city;
    private String hallType;
    private LocalDate date;
    private LocalTime startTime;
    private LocalTime endTime;
    private Integer minCapacity;
    private Integer maxCapacity;
    private BigDecimal minPrice;
    private BigDecimal maxPrice;
}