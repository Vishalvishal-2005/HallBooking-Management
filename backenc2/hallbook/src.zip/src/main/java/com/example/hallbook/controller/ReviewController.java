
// File: controller/ReviewController.java
package com.example.hallbook.controller;

import com.example.hallbook.dto.request.ReviewRequest;
import com.example.hallbook.dto.response.ReviewResponse;
import com.example.hallbook.security.CustomUserDetails;
import com.example.hallbook.service.ReviewService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/api/reviews")
@RequiredArgsConstructor
@CrossOrigin(origins = {"http://localhost:3000", "http://localhost:5173"}, allowCredentials = "true")
public class ReviewController {

    private final ReviewService reviewService;

    @PostMapping
    public ResponseEntity<ReviewResponse> createReview(
            @Valid @RequestBody ReviewRequest request,
            @AuthenticationPrincipal CustomUserDetails userDetails) {
        ReviewResponse response = reviewService.createReview(request, userDetails.getId());
        return ResponseEntity.status(HttpStatus.CREATED).body(response);
    }

    @GetMapping("/hall/{hallId}")
    public ResponseEntity<List<ReviewResponse>> getHallReviews(@PathVariable Long hallId) {
        List<ReviewResponse> reviews = reviewService.getHallReviews(hallId);
        return ResponseEntity.ok(reviews);
    }

    @GetMapping("/my-reviews")
    public ResponseEntity<List<ReviewResponse>> getUserReviews(
            @AuthenticationPrincipal CustomUserDetails userDetails) {
        List<ReviewResponse> reviews = reviewService.getUserReviews(userDetails.getId());
        return ResponseEntity.ok(reviews);
    }
}
