
// File: controller/HallController.java
package com.example.hallbook.controller;

import com.example.hallbook.dto.request.HallRequest;
import com.example.hallbook.dto.response.ApiResponse;
import com.example.hallbook.dto.response.HallResponse;
import com.example.hallbook.entity.HallType;
import com.example.hallbook.security.CustomUserDetails;
import com.example.hallbook.service.HallService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;
import java.math.BigDecimal;
import java.util.List;

@RestController
@RequestMapping("/api/halls")
@RequiredArgsConstructor
@CrossOrigin(origins = {"http://localhost:3000", "http://localhost:5173"}, allowCredentials = "true")
public class HallController {

    private final HallService hallService;

    @PostMapping
    public ResponseEntity<HallResponse> createHall(
            @Valid @RequestBody HallRequest request,
            @AuthenticationPrincipal CustomUserDetails userDetails) {
        HallResponse response = hallService.createHall(request, userDetails.getId());
        return ResponseEntity.status(HttpStatus.CREATED).body(response);
    }

    @GetMapping("/search")
    public ResponseEntity<List<HallResponse>> searchHalls(
            @RequestParam(required = false) String city,
            @RequestParam(required = false) BigDecimal minPrice,
            @RequestParam(required = false) BigDecimal maxPrice,
            @RequestParam(required = false) Integer capacity,
            @RequestParam(required = false) HallType hallType,
            @RequestParam(defaultValue = "rating") String sortBy) {
        List<HallResponse> halls = hallService.searchHalls(city, minPrice, maxPrice, 
                                                            capacity, hallType, sortBy);
        return ResponseEntity.ok(halls);
    }

    @GetMapping("/{id}")
    public ResponseEntity<HallResponse> getHallById(@PathVariable Long id) {
        HallResponse hall = hallService.getHallById(id);
        return ResponseEntity.ok(hall);
    }

    @GetMapping("/owner/my-halls")
    public ResponseEntity<List<HallResponse>> getOwnerHalls(
            @AuthenticationPrincipal CustomUserDetails userDetails) {
        List<HallResponse> halls = hallService.getOwnerHalls(userDetails.getId());
        return ResponseEntity.ok(halls);
    }

    @PutMapping("/{id}")
    public ResponseEntity<HallResponse> updateHall(
            @PathVariable Long id,
            @Valid @RequestBody HallRequest request,
            @AuthenticationPrincipal CustomUserDetails userDetails) {
        HallResponse response = hallService.updateHall(id, request, userDetails.getId());
        return ResponseEntity.ok(response);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<ApiResponse> deleteHall(
            @PathVariable Long id,
            @AuthenticationPrincipal CustomUserDetails userDetails) {
        hallService.deleteHall(id, userDetails.getId());
        return ResponseEntity.ok(new ApiResponse(true, "Hall deleted successfully"));
    }
}
