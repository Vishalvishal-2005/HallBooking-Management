
// File: entity/HallType.java
package com.example.hallbook.entity;

public enum HallType {
    WEDDING, CONFERENCE, BIRTHDAY, MEETING, BANQUET, OTHER
}