
// File: entity/PaymentStatus.java
package com.example.hallbook.entity;

public enum PaymentStatus {
    PENDING, PAID, REFUNDED
}