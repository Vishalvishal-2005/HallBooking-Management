package com.example.hallbook.entity;

public @interface NotBlank {

}
