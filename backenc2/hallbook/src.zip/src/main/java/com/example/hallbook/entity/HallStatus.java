// File: entity/HallStatus.java
package com.example.hallbook.entity;

public enum HallStatus {
    PENDING, APPROVED, REJECTED
}
