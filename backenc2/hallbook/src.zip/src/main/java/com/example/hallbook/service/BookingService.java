
// File: service/BookingService.java
package com.example.hallbook.service;

import com.example.hallbook.dto.request.BookingRequest;
import com.example.hallbook.dto.response.BookingResponse;
import com.example.hallbook.entity.*;
import com.example.hallbook.exception.BadRequestException;
import com.example.hallbook.exception.ResourceNotFoundException;
import com.example.hallbook.exception.UnauthorizedException;
import com.example.hallbook.repository.BookingRepository;
import com.example.hallbook.repository.HallRepository;
import com.example.hallbook.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.Duration;
import java.time.LocalTime;
import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class BookingService {

    private final BookingRepository bookingRepository;
    private final HallRepository hallRepository;
    private final UserRepository userRepository;
    private final NotificationService notificationService;

    @Transactional
    public BookingResponse createBooking(BookingRequest request, Long userId) {
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new ResourceNotFoundException("User not found"));

        Hall hall = hallRepository.findById(request.getHallId())
                .orElseThrow(() -> new ResourceNotFoundException("Hall not found"));

        if (!hall.getIsActive() || hall.getStatus() != HallStatus.APPROVED) {
            throw new BadRequestException("Hall is not available for booking");
        }

        if (request.getGuestCount() > hall.getCapacity()) {
            throw new BadRequestException("Guest count exceeds hall capacity");
        }

        if (request.getStartTime().isAfter(request.getEndTime())) {
            throw new BadRequestException("Start time must be before end time");
        }

        boolean hasConflict = bookingRepository.existsConflictingBooking(
                request.getHallId(),
                request.getBookingDate(),
                request.getStartTime(),
                request.getEndTime()
        );

        if (hasConflict) {
            throw new BadRequestException("Hall is already booked for the selected time slot");
        }

        BigDecimal durationHours = calculateDuration(request.getStartTime(), request.getEndTime());
        BigDecimal totalAmount = hall.getPricePerHour().multiply(durationHours);

        Booking booking = Booking.builder()
                .user(user)
                .hall(hall)
                .bookingDate(request.getBookingDate())
                .startTime(request.getStartTime())
                .endTime(request.getEndTime())
                .durationHours(durationHours)
                .totalAmount(totalAmount)
                .eventType(request.getEventType())
                .guestCount(request.getGuestCount())
                .specialRequests(request.getSpecialRequests())
                .status(BookingStatus.PENDING)
                .paymentStatus(PaymentStatus.PENDING)
                .build();

        Booking savedBooking = bookingRepository.save(booking);

        notificationService.createNotification(
                user,
                "Booking Created",
                "Your booking for " + hall.getName() + " has been created successfully",
                NotificationType.BOOKING
        );

        notificationService.createNotification(
                hall.getOwner(),
                "New Booking Request",
                "New booking request for " + hall.getName() + " from " + user.getFullName(),
                NotificationType.BOOKING
        );

        return mapToBookingResponse(savedBooking);
    }

    public List<BookingResponse> getUserBookings(Long userId) {
        return bookingRepository.findUserBookingsOrderedByDate(userId).stream()
                .map(this::mapToBookingResponse)
                .collect(Collectors.toList());
    }

    public List<BookingResponse> getOwnerBookings(Long ownerId) {
        return bookingRepository.findOwnerBookings(ownerId).stream()
                .map(this::mapToBookingResponse)
                .collect(Collectors.toList());
    }

    public BookingResponse getBookingById(Long id, Long userId) {
        Booking booking = bookingRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Booking not found"));

        User user = userRepository.findById(userId)
                .orElseThrow(() -> new ResourceNotFoundException("User not found"));

        if (!booking.getUser().getId().equals(userId) &&
            !booking.getHall().getOwner().getId().equals(userId) &&
            user.getRole() != Role.ADMIN) {
            throw new UnauthorizedException("You don't have permission to view this booking");
        }

        return mapToBookingResponse(booking);
    }

    @Transactional
    public BookingResponse confirmBooking(Long id, Long ownerId) {
        Booking booking = bookingRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Booking not found"));

        if (!booking.getHall().getOwner().getId().equals(ownerId)) {
            throw new UnauthorizedException("Only hall owner can confirm bookings");
        }

        if (booking.getPaymentStatus() != PaymentStatus.PAID) {
            throw new BadRequestException("Payment must be completed before confirmation");
        }

        booking.setStatus(BookingStatus.CONFIRMED);
        Booking confirmed = bookingRepository.save(booking);

        notificationService.createNotification(
                booking.getUser(),
                "Booking Confirmed",
                "Your booking for " + booking.getHall().getName() + " has been confirmed",
                NotificationType.BOOKING
        );

        return mapToBookingResponse(confirmed);
    }

    @Transactional
    public BookingResponse cancelBooking(Long id, Long userId, String reason) {
        Booking booking = bookingRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Booking not found"));

        User user = userRepository.findById(userId)
                .orElseThrow(() -> new ResourceNotFoundException("User not found"));

        if (!booking.getUser().getId().equals(userId) &&
            !booking.getHall().getOwner().getId().equals(userId) &&
            user.getRole() != Role.ADMIN) {
            throw new UnauthorizedException("You don't have permission to cancel this booking");
        }

        if (booking.getStatus() == BookingStatus.CANCELLED || booking.getStatus() == BookingStatus.COMPLETED) {
            throw new BadRequestException("Cannot cancel this booking");
        }

        booking.setStatus(BookingStatus.CANCELLED);
        booking.setCancellationReason(reason);

        if (booking.getPaymentStatus() == PaymentStatus.PAID) {
            booking.setPaymentStatus(PaymentStatus.REFUNDED);
        }

        Booking cancelled = bookingRepository.save(booking);

        notificationService.createNotification(
                booking.getUser(),
                "Booking Cancelled",
                "Your booking has been cancelled",
                NotificationType.CANCELLATION
        );

        return mapToBookingResponse(cancelled);
    }

    private BigDecimal calculateDuration(LocalTime start, LocalTime end) {
        Duration duration = Duration.between(start, end);
        long minutes = duration.toMinutes();
        return BigDecimal.valueOf(minutes).divide(BigDecimal.valueOf(60), 2, RoundingMode.HALF_UP);
    }

    private BookingResponse mapToBookingResponse(Booking booking) {
        String hallImage = booking.getHall().getImages() != null && !booking.getHall().getImages().isEmpty()
                ? booking.getHall().getImages().get(0).getImageUrl()
                : null;

        return BookingResponse.builder()
                .id(booking.getId())
                .userId(booking.getUser().getId())
                .userName(booking.getUser().getFullName())
                .userEmail(booking.getUser().getEmail())
                .hallId(booking.getHall().getId())
                .hallName(booking.getHall().getName())
                .hallCity(booking.getHall().getCity())
                .hallImage(hallImage)
                .bookingDate(booking.getBookingDate())
                .startTime(booking.getStartTime())
                .endTime(booking.getEndTime())
                .durationHours(booking.getDurationHours())
                .totalAmount(booking.getTotalAmount())
                .eventType(booking.getEventType())
                .guestCount(booking.getGuestCount())
                .specialRequests(booking.getSpecialRequests())
                .status(booking.getStatus())
                .paymentStatus(booking.getPaymentStatus())
                .paymentId(booking.getPaymentId())
                .build();
    }
}
