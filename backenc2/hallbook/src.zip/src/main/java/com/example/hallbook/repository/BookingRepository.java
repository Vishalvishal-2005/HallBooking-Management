
// File: repository/BookingRepository.java
package com.example.hallbook.repository;

import com.example.hallbook.entity.Booking;
import com.example.hallbook.entity.BookingStatus;
import com.example.hallbook.entity.Hall;
import com.example.hallbook.entity.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;

@Repository
public interface BookingRepository extends JpaRepository<Booking, Long> {
    List<Booking> findByUser(User user);
    List<Booking> findByUserId(Long userId);
    List<Booking> findByHall(Hall hall);
    List<Booking> findByHallId(Long hallId);
    List<Booking> findByStatus(BookingStatus status);
    
    @Query("SELECT b FROM Booking b WHERE b.user.id = :userId ORDER BY b.createdAt DESC")
    List<Booking> findUserBookingsOrderedByDate(@Param("userId") Long userId);
    
    @Query("SELECT b FROM Booking b WHERE b.hall.owner.id = :ownerId ORDER BY b.createdAt DESC")
    List<Booking> findOwnerBookings(@Param("ownerId") Long ownerId);
    
    @Query("SELECT CASE WHEN COUNT(b) > 0 THEN true ELSE false END FROM Booking b " +
           "WHERE b.hall.id = :hallId AND b.bookingDate = :bookingDate " +
           "AND b.status IN ('PENDING', 'CONFIRMED') " +
           "AND ((b.startTime < :endTime AND b.endTime > :startTime))")
    boolean existsConflictingBooking(@Param("hallId") Long hallId,
                                     @Param("bookingDate") LocalDate bookingDate,
                                     @Param("startTime") LocalTime startTime,
                                     @Param("endTime") LocalTime endTime);
    
    @Query("SELECT SUM(b.totalAmount) FROM Booking b WHERE b.status = 'COMPLETED'")
    BigDecimal calculateTotalRevenue();
    
    List<Booking> findByBookingDateBetween(LocalDate startDate, LocalDate endDate);
}
