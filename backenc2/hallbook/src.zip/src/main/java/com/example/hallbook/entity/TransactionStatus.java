
// File: entity/TransactionStatus.java
package com.example.hallbook.entity;

public enum TransactionStatus {
    SUCCESS, FAILED, PENDING
}