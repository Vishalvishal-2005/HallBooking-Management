package com.example.hallbook.dto.request;

import lombok.*;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class ReviewRequest {
    private Long bookingId;
    private Long hallId;
    private Integer rating;
    private String reviewText;
}
