
// File: entity/NotificationType.java
package com.example.hallbook.entity;

public enum NotificationType {
    BOOKING, PAYMENT, APPROVAL, CANCELLATION, REMINDER
}