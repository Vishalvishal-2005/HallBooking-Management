
// File: service/ReviewService.java
package com.example.hallbook.service;

import com.example.hallbook.dto.request.ReviewRequest;
import com.example.hallbook.dto.response.ReviewResponse;
import com.example.hallbook.entity.*;
import com.example.hallbook.exception.BadRequestException;
import com.example.hallbook.exception.ResourceNotFoundException;
import com.example.hallbook.repository.BookingRepository;
import com.example.hallbook.repository.HallRepository;
import com.example.hallbook.repository.ReviewRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class ReviewService {

    private final ReviewRepository reviewRepository;
    private final BookingRepository bookingRepository;
    private final HallRepository hallRepository;

    @Transactional
    public ReviewResponse createReview(ReviewRequest request, Long userId) {
        Booking booking = bookingRepository.findById(request.getBookingId())
                .orElseThrow(() -> new ResourceNotFoundException("Booking not found"));

        if (!booking.getUser().getId().equals(userId)) {
            throw new BadRequestException("You can only review your own bookings");
        }

        if (booking.getStatus() != BookingStatus.COMPLETED) {
            throw new BadRequestException("Can only review completed bookings");
        }

        if (reviewRepository.existsByBooking(booking)) {
            throw new BadRequestException("Review already exists for this booking");
        }

        Review review = Review.builder()
                .booking(booking)
                .user(booking.getUser())
                .hall(booking.getHall())
                .rating(request.getRating())
                .reviewText(request.getReviewText())
                .build();

        Review savedReview = reviewRepository.save(review);
        updateHallRating(booking.getHall().getId());

        return mapToReviewResponse(savedReview);
    }

    public List<ReviewResponse> getHallReviews(Long hallId) {
        return reviewRepository.findByHallIdOrderByCreatedAtDesc(hallId).stream()
                .map(this::mapToReviewResponse)
                .collect(Collectors.toList());
    }

    public List<ReviewResponse> getUserReviews(Long userId) {
        User user = new User();
        user.setId(userId);
        return reviewRepository.findByUser(user).stream()
                .map(this::mapToReviewResponse)
                .collect(Collectors.toList());
    }

    @Transactional
    public void updateHallRating(Long hallId) {
        Double avgRating = reviewRepository.calculateAverageRating(hallId);
        if (avgRating != null) {
            Hall hall = hallRepository.findById(hallId)
                    .orElseThrow(() -> new ResourceNotFoundException("Hall not found"));
            hall.setRating(BigDecimal.valueOf(avgRating).setScale(2, RoundingMode.HALF_UP));
            hallRepository.save(hall);
        }
    }

    private ReviewResponse mapToReviewResponse(Review review) {
        return ReviewResponse.builder()
                .id(review.getId())
                .bookingId(review.getBooking().getId())
                .userId(review.getUser().getId())
                .hallName(review.getHall().getName())
                .rating(review.getRating())
                .reviewText(review.getReviewText())
                .createdAt(review.getCreatedAt())
                .build();
    }
}

