
// File: repository/HallRepository.java
package com.example.hallbook.repository;

import com.example.hallbook.entity.Hall;
import com.example.hallbook.entity.HallStatus;
import com.example.hallbook.entity.HallType;
import com.example.hallbook.entity.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import java.math.BigDecimal;
import java.util.List;

@Repository
public interface HallRepository extends JpaRepository<Hall, Long> {
    List<Hall> findByOwner(User owner);
    List<Hall> findByOwnerId(Long ownerId);
    List<Hall> findByStatus(HallStatus status);
    List<Hall> findByIsActiveTrue();
    
    @Query("SELECT h FROM Hall h WHERE h.isActive = true AND h.status = 'APPROVED' " +
           "AND (:city IS NULL OR LOWER(h.city) LIKE LOWER(CONCAT('%', :city, '%'))) " +
           "AND (:minPrice IS NULL OR h.pricePerHour >= :minPrice) " +
           "AND (:maxPrice IS NULL OR h.pricePerHour <= :maxPrice) " +
           "AND (:capacity IS NULL OR h.capacity >= :capacity) " +
           "AND (:hallType IS NULL OR h.hallType = :hallType)")
    List<Hall> searchHalls(@Param("city") String city,
                          @Param("minPrice") BigDecimal minPrice,
                          @Param("maxPrice") BigDecimal maxPrice,
                          @Param("capacity") Integer capacity,
                          @Param("hallType") HallType hallType);
    
    @Query("SELECT h FROM Hall h WHERE h.status = 'PENDING' ORDER BY h.createdAt DESC")
    List<Hall> findPendingApprovals();
    
    @Query("SELECT COUNT(h) FROM Hall h WHERE h.status = 'PENDING'")
    Long countPendingApprovals();
}