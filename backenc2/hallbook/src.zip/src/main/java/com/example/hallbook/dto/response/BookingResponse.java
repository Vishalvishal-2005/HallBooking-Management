package com.example.hallbook.dto.response;

import lombok.*;
import lombok.Builder;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class BookingResponse {
    private Long id;
    private Long hallId;
    private String hallName;
    private LocalDate bookingDate;
    private LocalTime startTime;
    private LocalTime endTime;
    private BigDecimal durationHours;
    private BigDecimal totalAmount;
    private String eventType;
    private Integer guestCount;
    private String status;
    private String paymentStatus;
    private LocalDateTime createdAt;
}
