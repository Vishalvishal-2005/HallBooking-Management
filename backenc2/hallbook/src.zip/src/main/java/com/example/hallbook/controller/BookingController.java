
// File: controller/BookingController.java
package com.example.hallbook.controller;

import com.example.hallbook.dto.request.BookingRequest;
import com.example.hallbook.dto.response.BookingResponse;
import com.example.hallbook.security.CustomUserDetails;
import com.example.hallbook.service.BookingService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/api/bookings")
@RequiredArgsConstructor
@CrossOrigin(origins = {"http://localhost:3000", "http://localhost:5173"}, allowCredentials = "true")
public class BookingController {

    private final BookingService bookingService;

    @PostMapping
    public ResponseEntity<BookingResponse> createBooking(
            @Valid @RequestBody BookingRequest request,
            @AuthenticationPrincipal CustomUserDetails userDetails) {
        BookingResponse response = bookingService.createBooking(request, userDetails.getId());
        return ResponseEntity.status(HttpStatus.CREATED).body(response);
    }

    @GetMapping("/my-bookings")
    public ResponseEntity<List<BookingResponse>> getUserBookings(
            @AuthenticationPrincipal CustomUserDetails userDetails) {
        List<BookingResponse> bookings = bookingService.getUserBookings(userDetails.getId());
        return ResponseEntity.ok(bookings);
    }

    @GetMapping("/owner-bookings")
    public ResponseEntity<List<BookingResponse>> getOwnerBookings(
            @AuthenticationPrincipal CustomUserDetails userDetails) {
        List<BookingResponse> bookings = bookingService.getOwnerBookings(userDetails.getId());
        return ResponseEntity.ok(bookings);
    }

    @GetMapping("/{id}")
    public ResponseEntity<BookingResponse> getBookingById(
            @PathVariable Long id,
            @AuthenticationPrincipal CustomUserDetails userDetails) {
        BookingResponse booking = bookingService.getBookingById(id, userDetails.getId());
        return ResponseEntity.ok(booking);
    }

    @PutMapping("/{id}/confirm")
    public ResponseEntity<BookingResponse> confirmBooking(
            @PathVariable Long id,
            @AuthenticationPrincipal CustomUserDetails userDetails) {
        BookingResponse response = bookingService.confirmBooking(id, userDetails.getId());
        return ResponseEntity.ok(response);
    }

    @PutMapping("/{id}/cancel")
    public ResponseEntity<BookingResponse> cancelBooking(
            @PathVariable Long id,
            @RequestParam(required = false) String reason,
            @AuthenticationPrincipal CustomUserDetails userDetails) {
        BookingResponse response = bookingService.cancelBooking(id, userDetails.getId(), reason);
        return ResponseEntity.ok(response);
    }
}
