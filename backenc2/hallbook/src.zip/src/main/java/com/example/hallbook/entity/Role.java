package com.example.hallbook.entity;

public enum Role {
    CUSTOMER, OWNER, ADMIN
}
