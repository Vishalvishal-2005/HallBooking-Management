package com.example.hallbook.dto.response;

import lombok.*;
import java.time.LocalDateTime;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class ReviewResponse {
    private Long id;
    private long userId;
    private String hallName;
    private Integer rating;
    private String reviewText;
    private long bookingId;
    private LocalDateTime createdAt;
}
