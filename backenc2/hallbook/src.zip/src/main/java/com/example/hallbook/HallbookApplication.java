package com.example.hallbook;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HallbookApplication {

	public static void main(String[] args) {
		SpringApplication.run(HallbookApplication.class, args);
	}

}
