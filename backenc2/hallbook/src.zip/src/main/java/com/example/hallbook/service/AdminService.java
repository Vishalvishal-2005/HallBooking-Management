
// File: service/AdminService.java
package com.example.hallbook.service;

import com.example.hallbook.dto.response.AdminStatsResponse;
import com.example.hallbook.dto.response.HallResponse;
import com.example.hallbook.entity.*;
import com.example.hallbook.exception.ResourceNotFoundException;
import com.example.hallbook.repository.*;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.math.BigDecimal;
import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class AdminService {

    private final HallRepository hallRepository;
    private final UserRepository userRepository;
    private final BookingRepository bookingRepository;
    private final NotificationService notificationService;
    private final HallService hallService;

    public AdminStatsResponse getAdminStats() {
        Long totalHalls = hallRepository.count();
        Long pendingApprovals = hallRepository.countPendingApprovals();
        Long totalBookings = bookingRepository.count();
        Long totalUsers = userRepository.count();
        BigDecimal totalRevenue = bookingRepository.calculateTotalRevenue();
        Long activeCustomers = userRepository.countActiveUsersByRole(Role.CUSTOMER);
        Long activeOwners = userRepository.countActiveUsersByRole(Role.OWNER);

        return AdminStatsResponse.builder()
                .totalHalls(totalHalls)
                .pendingApprovals(pendingApprovals)
                .totalBookings(totalBookings)
                .totalUsers(totalUsers)
                .totalRevenue(totalRevenue != null ? totalRevenue : BigDecimal.ZERO)
                .activeCustomers(activeCustomers)
                .activeOwners(activeOwners)
                .build();
    }

    public List<HallResponse> getPendingHallApprovals() {
        return hallRepository.findPendingApprovals().stream()
                .map(hallService::mapToHallResponse)
                .collect(Collectors.toList());
    }

    @Transactional
    public void approveHall(Long hallId) {
        Hall hall = hallRepository.findById(hallId)
                .orElseThrow(() -> new ResourceNotFoundException("Hall not found"));

        hall.setStatus(HallStatus.APPROVED);
        hallRepository.save(hall);

        notificationService.createNotification(
                hall.getOwner(),
                "Hall Approved",
                "Your hall '" + hall.getName() + "' has been approved and is now live",
                NotificationType.APPROVAL
        );
    }

    @Transactional
    public void rejectHall(Long hallId, String reason) {
        Hall hall = hallRepository.findById(hallId)
                .orElseThrow(() -> new ResourceNotFoundException("Hall not found"));

        hall.setStatus(HallStatus.REJECTED);
        hallRepository.save(hall);

        String message = "Your hall '" + hall.getName() + "' has been rejected";
        if (reason != null && !reason.isEmpty()) {
            message += ". Reason: " + reason;
        }

        notificationService.createNotification(
                hall.getOwner(),
                "Hall Rejected",
                message,
                NotificationType.APPROVAL
        );
    }

    @Transactional
    public void deactivateUser(Long userId) {
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new ResourceNotFoundException("User not found"));

        user.setIsActive(false);
        userRepository.save(user);
    }
}
        