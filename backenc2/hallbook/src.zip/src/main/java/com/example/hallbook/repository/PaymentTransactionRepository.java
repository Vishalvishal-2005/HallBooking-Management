
// File: repository/PaymentTransactionRepository.java
package com.example.hallbook.repository;

import com.example.hallbook.entity.Booking;
import com.example.hallbook.entity.PaymentTransaction;
import com.example.hallbook.entity.TransactionStatus;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.List;
import java.util.Optional;

@Repository
public interface PaymentTransactionRepository extends JpaRepository<PaymentTransaction, Long> {
    List<PaymentTransaction> findByBooking(Booking booking);
    Optional<PaymentTransaction> findByTransactionId(String transactionId);
    List<PaymentTransaction> findByStatus(TransactionStatus status);
    List<PaymentTransaction> findByBookingId(Long bookingId);
}
