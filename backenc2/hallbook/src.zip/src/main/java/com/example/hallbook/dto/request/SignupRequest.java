// File: dto/request/SignupRequest.java
package com.example.hallbook.dto.request;

import lombok.*;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class SignupRequest {
    private String username;
    private String email;
    private String password;
    private String fullName;
    private String phone;
    private String role;
}